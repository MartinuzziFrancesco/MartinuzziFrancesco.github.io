using BenchmarkTools, Plots

"""
Naive implementation of sum. Works for any iterable `x` with any element type.
"""
function my_sum(x)
    result = zero(eltype(x))
    for element in x
        result += element
    end
    return result
end

#test data
data = rand(Float64, 10^7)

@benchmark my_sum(data)
@btime my_sum(data)

#how about c now
"""
Call the `strcmp` function from `libc.so.6`
"""
function c_compare(x::String, y::String)
    # We have to tell the compiler that this C function returns an `int` and 
    # expects two `char *` inputs. The `Cint` and `Cstring` types are convenient
    # shorthands for those:
    ccall((:strcmp, "libc.so.6"), Cint, (Cstring, Cstring), x, y)
end
c_compare("hello", "hello")
#ccall overhead
@btime c_compare($("hello"), $("hello"))

#my_sum in C


C_code = """

#include <stddef.h>  // For `size_t`

// Note: our Julia code works for any type, but the C implementation 
// is only for `double`.

double c_sum(size_t n, double *X) {
    double s = 0.0;
    size_t i;
    for (i = 0; i < n; ++i) {
        s += X[i];
    }
    return s;
}

""";
#generate a name for the library
# dlext gives the correct file extension for a shared library on this platform
using Libdl: dlext
const Clib = tempname() * "." * dlext

#send the code to gcc
open(`gcc -fPIC -O3 -msse3 -xc -shared -o $Clib -`, "w") do cmd
    print(cmd, C_code) 
end

#create the c function from julia
# The return type and argument types must match the signature we declared above:
# 
#   double c_sum(size_t n, double *X) 
# 
c_sum(X::Array{Float64}) = ccall(("c_sum", Clib), Cdouble, (Csize_t, Ptr{Cdouble}), length(X), X)

#benchmark the c function
@btime c_sum(data)

#plot the results

results = [
    "my_sum (Julia)" => 8.26,
    "c_sum (C)" => 8.26
]

bar(first.(results), last.(results), xlabel="function", ylabel="time (ms, shorter is better)", legend=nothing)

#how about the built in sum function in Julia?
@btime sum(data)
results = [
    "my_sum (Julia)" => 8.3,
    "c_sum (C)" => 8.3,
    "sum (Julia)" => 3.1,
]

bar(first.(results), last.(results), xlabel="function", ylabel="time (ms, shorter is better)", legend=nothing)

#what's the magic?
function my_fast_sum(x)
    result = zero(eltype(x))
    
    # `@inbounds` is a macro which disables all bounds checking within a given block. 
    #
    # `@simd` enables additional vector operations by indicating that it is OK to potentially
    # evaluate the loop out-of-order. 
    @inbounds @simd for element in x
        result += element
    end
    result
end
@btime my_fast_sum(data)

results = [
    "my_sum (Julia)" => 8.3,
    "c_sum (C)" => 8.3,
    "sum (Julia)" => 3.1,
    "my_fast_sum (Julia)" => 2.9,
]

bar(first.(results), last.(results), xlabel="function", ylabel="time (ms, shorter is better)", legend=nothing)

#ok cool, now let's see python sum function
using PyCall

py_math = pyimport("math")
py_math.sin(1.0)

# The PyCall package lets us define python functions directly from Julia:

py"""
def mysum(a):
    s = 0.0
    for x in a:
        s = s + x
    return s
"""

# mysum_py is a reference to the Python mysum function
py_sum = py"""mysum"""o

#wait, are all these functions actually doing the same thing?
py_sum(data) ≈ c_sum(data) ≈ sum(data) ≈ my_sum(data) ≈ my_fast_sum(data)

#benchmark python
@btime py_sum(data)



results = [
    "my_sum (Julia)" => 8.3,
    "c_sum (C)" => 8.3,
    "sum (Julia)" => 3.1,
    "my_fast_sum (Julia)" => 2.9,
    "py_sum (Python)" => 451.4,
]

bar(first.(results), last.(results), xlabel="function", ylabel="time (ms, shorter is better)", legend=nothing)