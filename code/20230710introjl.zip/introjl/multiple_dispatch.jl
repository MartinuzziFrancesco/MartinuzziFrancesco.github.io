@which 1 + 1
@which true + true
@which 1.0 + 1.0

methods(+)

using Dates
Date(2023, 07, 10) + Day(50)

@which Date(2023, 07, 10) + Day(50)

using Measurements

x = 1.0 ± 0.1
y = 2.3 ± 1.5
z = 5.9 ± 3.1

x+y
(x+y)*z
(x+y)z

@which x+y

using Unitful

x = (1.0 ± 0.1)u"m/s"
y = (2.3 ± 1.5)u"s"
z = (5.9 ± 3.1)u"kg"

typeof(x)

x+x
x+y